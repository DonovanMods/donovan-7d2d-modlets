# Donovan BetterVehicles

## 7 Days 2 Die Modlet

Updates the vehicles to be bigger and faster.

- Increased Storage
- All vehicles are now 25% faster normal speed, and double that for turbo mode.

Notes:

In an attempt to make each vehicle useful to some degree, these are the changes I've made...

- Motorcycle is the fastest land vehicle, but has less storage than the 4x4 (but more than the Gyro).
- 4x4 has the most storage of any vehicle, but is slightly slower than the Motorcycle.
- Gyrocopter is the fastest vehicle of all, but has limited storage.

ToDo:

If/When I can figure out what settings control the damage they do to Z's when you hit them, I'll increase that too.
