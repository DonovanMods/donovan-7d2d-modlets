# Donovan UI

## 7 Days 2 Die Modlet

A very simple customized UI

- Moves the food and water bars to the Left HUD underneath the health/stamina bars
- Moves the EXP bar to underneath the toolbelt and makes it slightly larger
- Adds the "locked slots" functionality back into the UI for the sort/stash buttons.
- Add Elevation data to the Compass

_This mod has been renamed from `donovan-ui-simple`_
