# Donovan Zombie Wraith

## 7 Days 2 Die Modlet

This modlet adds a new zombie type to the game, the Wraith. It's a fast, agile, and deadly zombie that comes out at night.
