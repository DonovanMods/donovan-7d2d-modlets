# Donovan ModSchematics

## 7 Days 2 Die Modlet

Have you ever found a weapon mod but wished you had the schematic for it instead?
Well, now you can! Using the workbench, some paper, glue, and leather you can turn that mod into a schematic of the same type!

Of course, in order to make the schematic, the original mod will be consumed in the process, but you'll have a shiny new schematic to read!

Special Thanks to Steveburger (aka Khar Brons) for his help and ideas on this modlet!
