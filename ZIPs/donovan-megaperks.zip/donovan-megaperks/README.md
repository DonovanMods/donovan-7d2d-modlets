# Donovan MegaPerks

## 7 Days 2 Die Modlet

Increases the number of perks you gain per level to 4.
