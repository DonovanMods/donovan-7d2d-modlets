# Donovan NightFog

## 7 Days 2 Die Modlet

With this modlet loaded, an unearthly fog will roll in at night, giving the game an even more creepy feeling.
