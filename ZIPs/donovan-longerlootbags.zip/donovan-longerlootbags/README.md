# Donovan LongerLootbags

## 7 Days 2 Die Modlet

Decreases the decay rate on zombie loot bags from 5 to 30 minutes
