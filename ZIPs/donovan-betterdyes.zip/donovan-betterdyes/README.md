# Donovan BetterDyes

## 7 Days 2 Die Modlet

This modlet adds the ability to craft dyes from paint.
